#!/usr/bin/env python
# -*- coding: utf-8 -*-

ROOT_TILE_URL = 'tile.openweathermap.org/map'

NAMED_MAP_LAYER_URL = '%s'
